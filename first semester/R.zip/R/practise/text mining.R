 install.packages(c("tm", "SnowballC", "twitteR",  "wordcloud", "topicmodels"))
load(file="rdm")